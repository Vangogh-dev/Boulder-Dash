package model;
/**
 * 
 */
import contract.Idirt;
/**
 * 
 * @author Rodrigue
 *
 */
public class Dirt extends Sprite implements Idirt {
/**
 * 
 * @param pX
 * @param pY
 */
	public Dirt(int pX, int pY) {
		super(pX, pY);
		this.path = "dirt.png";
		this.setImage();
	}
/**
 * 
 */
	public String toString() {
		return "type:Dirt " + super.toString();
	}
}
