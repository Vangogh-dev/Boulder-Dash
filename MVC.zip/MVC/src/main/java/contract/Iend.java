package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Iend {
/**
 * 
 * @return
 */
	String toString();
/**
 * 
 */
	void update();
/**
 * 
 * @param pBool
 */
	void setIsSolid(Boolean pBool);
}
