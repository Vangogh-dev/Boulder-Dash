package contract;
/**
 * 
 */
import model.Hero;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Imap {
/**
 * 
 * @param pTable
 */
	void load(int[][] pTable);
/**
 * 
 */
	void update();
/**
 * 
 * @return
 */
	Hero getHero();
}
