package contract;
/**
 * 
 */
import java.awt.event.ActionEvent;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Ienemy {
/**
 * 
 * @param evt
 */
	void actionPerformed(ActionEvent evt);
/**
 * 
 */
	void move();

}
