package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Iview {
/**
 * 
 * @param pMap
 */
	void setMap(String pMap);
/**
 * 
 */
	void init();
}
