package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Iblock {
/**
 * 
 * @return
 */
	String toString();
}
