package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Irock {
/**
 * 
 * @return
 */
	String toString();
/**
 * 
 */
	void update();
}
