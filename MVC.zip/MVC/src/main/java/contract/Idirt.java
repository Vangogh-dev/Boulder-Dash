package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Idirt {
/**
 * 
 * @return
 */
	String toString();
}
