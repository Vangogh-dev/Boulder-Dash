package contract;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Idiamond {
/**
 * 
 * @return
 */
	String toString();
/**
 * 
 */
	void update();
}
