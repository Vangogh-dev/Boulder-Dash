package contract;
/**
 * 
 */
import java.awt.Graphics;
import java.awt.event.ActionEvent;
/**
 * 
 * @author Rodrigue
 *
 */
public interface Isprite {
/**
 * 
 * @param evt
 */
	void actionPerformed(ActionEvent evt);
/**
 * 
 * @param pPath
 * @param pX
 * @param pY
 */
	void Sprite(String pPath, int pX, int pY);
/**
 * 
 */
	void applyGravity();
/**
 * 
 */
	void update();
/*
 * @param Graphics g
 */
	void paintComponent(Graphics g);
/**
 * 
 */
	void setImage();
/**
 * @param pX
 */
	void setX(int pX);
	
/**
 * 
 * @param pY
 */
	void setY(int pY);
/**
 * 
 * @param pBool
 */
	void setIsSolid(Boolean pBool);
/**
 * 
 * @param pBool
 */
	void setIsActive(Boolean pBool);
/**
 * 
 * @param pPath
 */
	void setPath(String pPath);
/**
 * 
 * @param pSpeed
 */
	void setSpeed(int pSpeed);
/**
 * 
 * @param pBool
 */
	void setAlive(Boolean pBool);
/**
 * 
 * @return
 */
	Boolean getAlive();
/**
 * 
 * @return
 */
	Boolean getIsSolid();
/**
 * 
 * @return
 */
	int getSpeed();
/**
 * 
 * @return
 */
	Boolean getIsActive();

}
