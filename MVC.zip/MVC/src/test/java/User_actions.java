import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import junit.framework.TestCase;

public class User_actions extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testActionPerformed() {
        int keycode;
       Robot bot = null;
           try {
               bot = new Robot();
           } catch (AWTException e) {

               e.printStackTrace();
           }
           final int ve = 0 ;
           keycode = KeyEvent.VK_UP;
           bot.keyPress(keycode);

           Object b;
		assertEquals(ve,b.Ps);

   }

}
