import java.awt.Image;

import javax.swing.ImageIcon;

import junit.framework.TestCase;
import model.Sprite;

/**
 * 
 */

/**
 * @author Rodrigue
 *
 */
public class loadSpriteTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testGetEmty(int x, int y) {
        Sprite s = new Sprite(x , y);
        Image empty;
        ImageIcon img = new ImageIcon("empty.png");
        empty = img.getImage();
        
        assertEquals(empty,s.getEmpty());
    }

}
